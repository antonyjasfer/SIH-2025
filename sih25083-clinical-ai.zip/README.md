# SIH25083 Clinical AI Project

Prototype repo.
