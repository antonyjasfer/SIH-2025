# SQLAlchemy models (User, Patient, ClinicalNote)
