# Password hashing functions
