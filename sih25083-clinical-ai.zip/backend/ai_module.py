# OpenAI API integration for note generation
