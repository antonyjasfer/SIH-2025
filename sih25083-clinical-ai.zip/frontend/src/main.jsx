// React main entrypoint
