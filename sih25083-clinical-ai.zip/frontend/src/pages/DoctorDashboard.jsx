// Doctor dashboard component
